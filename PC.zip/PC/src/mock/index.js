// import Mock from 'mockjs'

// import tableAPI from './table'
// // 设置全局延时 没有延时的话有时候会检测不到数据变化 建议保留
// Mock.setup({
//   timeout: newFunction()
// })


// // 用户相关
// Mock.mock(/\/user\/listpage/, 'get', tableAPI.getUserList)
// Mock.mock(/\/user\/remove/, 'get', tableAPI.deleteUser)
// Mock.mock(/\/user\/batchremove/, 'get', tableAPI.batchremove)
// Mock.mock(/\/user\/add/, 'get', tableAPI.createUser)
// Mock.mock(/\/user\/edit/, 'get', tableAPI.updateUser)
// export default Mock

// function newFunction() {
//   return '300-600';
// }
